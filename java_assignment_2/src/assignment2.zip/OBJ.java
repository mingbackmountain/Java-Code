//Thanakorn Pasangthien Section1 6088109
public class OBJ {
	int x;
	int y;
	public int sum(int x,int y) {
		return x+y;
	}
}
