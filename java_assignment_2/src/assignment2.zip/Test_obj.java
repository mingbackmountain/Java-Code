//Thanakorn Pasangthien Section1 6088109
public class Test_obj {
	public static void main(String[] args) {
		OBJ number = new OBJ();
		number.x = 6;
		number.y = 7;
		System.out.println(number.sum(number.x,number.y));
	}
}
