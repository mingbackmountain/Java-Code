//Thanakorn Pasangthien Section1 6088109
public class Student {
	private String name;
	private String email;
	Student(String Name, String Email){
		name = Name;
		email = Email;
	}
	public String getname() {
		return name;
	}
	public String getemail() {
		return email;
	}
}

